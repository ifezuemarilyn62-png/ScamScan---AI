# ScamScan AI
AI-Powered Scholarship & Job Scam Detector

## Overview
ScamScan AI instantly detects fake scholarships, job adverts, emails, and online opportunities. Users paste text or links, and the AI returns a scam score, verdict, and safety recommendations.

## Features
- AI Text Scam Analyzer  
- Link Safety Checker  
- Scam Score (0–100%)  
- Verdict: Safe / Suspicious / Likely Scam  
- Safety Recommendations  

## How It Works
1. User pastes text in the webpage  
2. AI script analyzes text for scam indicators  
3. Output shows scam score, verdict, and reasons  

## Tech Stack
- Frontend: HTML, CSS, JavaScript  
- Backend: Python (Flask/FastAPI optional)  
- AI: LLM / simple keyword analyzer  
- Version Control: GitHub  

## Demo
- Paste a text  
- Click “Scan for Scam”  
- See result instantly  

## Future Improvements
- Screenshot analyzer for fake logos  
- Database of known scams  
- Browser extension and mobile app version
