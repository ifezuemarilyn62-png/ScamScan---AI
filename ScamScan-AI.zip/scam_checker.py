# scam_checker.py
# ScamScan AI - Simple text analyzer

import re

def analyze_text(text):
    text_lower = text.lower()
    scam_keywords = [
        "urgent", "limited slots", "apply now", "free money", 
        "bank account", "wire transfer", "payment", "click here",
        "congratulations", "winner", "university grant", "scholarship award"
    ]
    
    score = 0
    reasons = []

    for word in scam_keywords:
        if word in text_lower:
            score += 10
            reasons.append(f"Contains suspicious keyword: '{word}'")

    if re.search(r'@gmail\.com|@yahoo\.com', text_lower):
        reasons.append("Uses personal email instead of official domain")
        score += 5

    if "100%" in text_lower or "guaranteed" in text_lower:
        reasons.append("Promises guaranteed benefits")
        score += 5

    score = min(score, 100)

    if score >= 50:
        verdict = "Likely Scam"
    elif score >= 20:
        verdict = "Suspicious"
    else:
        verdict = "Safe"

    return {
        "scam_score": score,
        "verdict": verdict,
        "reasons": reasons
    }

if __name__ == "__main__":
    sample_text = (
        "Congratulations! You have been selected for a 100% scholarship award. "
        "Apply now and send your bank account details immediately!"
    )
    result = analyze_text(sample_text)
    print("Scam Score:", result['scam_score'])
    print("Verdict:", result['verdict'])
    print("Reasons:", result['reasons'])
